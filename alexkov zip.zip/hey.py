print("cau z pythonu")
input("stlac enter ak che skoncit")